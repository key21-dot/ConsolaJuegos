package PPT;


import Base.Estadisticas;
import Base.RegistroEstadisticas;
import Base.Jugable;

public class PPT implements Jugable {

    private Estadisticas estadisticas;

    public PPT() {
        estadisticas = RegistroEstadisticas.ppt();
    }

    @Override
    public String getNombre() {
        return "Piedra, Papel o Tijera";
    }

    @Override
    public void star() {
        new VentanaPPT(estadisticas);
    }

    public Estadisticas getEstadisticas() {
        return estadisticas;
    }
}
