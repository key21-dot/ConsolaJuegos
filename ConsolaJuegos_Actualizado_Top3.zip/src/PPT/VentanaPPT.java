package PPT;

import Base.Estadisticas;
import javax.swing.*;
import java.awt.*;
import java.util.Random;


public class VentanaPPT extends JFrame {

    private Estadisticas estadisticas;
    private Random random;

    private JLabel lblRonda;
    private JLabel lblJugador;
    private JLabel lblComputadora;
    private JLabel lblResultado;
    private JLabel lblMarcador;

    private JButton btnPiedra;
    private JButton btnPapel;
    private JButton btnTijera;

    private int dificultad = 1;
    private int victoriasNecesarias = 2;
    private int puntosJugador;
    private int puntosComputadora;
    private int empates;
    private int ronda;
    private int ultimaEleccion;

    private boolean partidaTerminada;

    private Color fondo = new Color(15, 23, 42);
    private Color tarjeta = new Color(30, 41, 59);
    private Color azul = new Color(34, 211, 238);
    private Color verde = new Color(74, 222, 128);
    private Color rojo = new Color(251, 113, 133);

    private String[] opciones = {
            "PIEDRA", "PAPEL", "TIJERA"
    };

    public VentanaPPT(Estadisticas estadisticas) {

        this.estadisticas = estadisticas;
        this.random = new Random();

        setTitle("GameConsole - Piedra, Papel o Tijera");
        setSize(650, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);

        crearInterfaz();
        configurarPartida();

        setVisible(true);
    }

    public void crearInterfaz() {

        JPanel principal = new JPanel(new BorderLayout(15, 15));
        principal.setBackground(fondo);
        principal.setBorder(
                BorderFactory.createEmptyBorder(25, 30, 25, 30)
        );

        // TITULO
        JLabel titulo = new JLabel(
                "PIEDRA, PAPEL O TIJERA",
                SwingConstants.CENTER
        );

        titulo.setFont(new Font("Arial", Font.BOLD, 26));
        titulo.setForeground(azul);

        principal.add(titulo, BorderLayout.NORTH);

        // ZONA CENTRAL
        JPanel centro = new JPanel(new GridLayout(4, 1, 12, 12));
        centro.setBackground(fondo);

        lblRonda = new JLabel("RONDA 1", SwingConstants.CENTER);
        lblRonda.setForeground(Color.WHITE);
        lblRonda.setFont(new Font("Arial", Font.BOLD, 20));

        JPanel elecciones = new JPanel(new GridLayout(1, 2, 15, 15));
        elecciones.setBackground(fondo);

        lblJugador = crearEtiqueta("TU: ?");
        lblComputadora = crearEtiqueta("COMPUTADORA: ?");

        elecciones.add(lblJugador);
        elecciones.add(lblComputadora);

        lblResultado = new JLabel(
                "Selecciona una opcion",
                SwingConstants.CENTER
        );

        lblResultado.setFont(new Font("Arial", Font.BOLD, 19));
        lblResultado.setForeground(azul);

        lblMarcador = new JLabel(
                "Jugador: 0 | Computadora: 0 | Empates: 0",
                SwingConstants.CENTER
        );

        lblMarcador.setFont(new Font("Arial", Font.BOLD, 16));
        lblMarcador.setForeground(Color.WHITE);

        centro.add(lblRonda);
        centro.add(elecciones);
        centro.add(lblResultado);
        centro.add(lblMarcador);

        principal.add(centro, BorderLayout.CENTER);

        // BOTONES INFERIORES
        JPanel inferior = new JPanel(new GridLayout(2, 1, 10, 10));
        inferior.setBackground(fondo);

        JPanel panelOpciones = new JPanel(new GridLayout(1, 3, 10, 10));
        panelOpciones.setBackground(fondo);

        btnPiedra = crearBoton("PIEDRA");
        btnPapel = crearBoton("PAPEL");
        btnTijera = crearBoton("TIJERA");

        btnPiedra.addActionListener(e -> jugarRonda(1));
        btnPapel.addActionListener(e -> jugarRonda(2));
        btnTijera.addActionListener(e -> jugarRonda(3));

        panelOpciones.add(btnPiedra);
        panelOpciones.add(btnPapel);
        panelOpciones.add(btnTijera);

        JPanel panelControl = new JPanel(new GridLayout(1, 2, 10, 10));
        panelControl.setBackground(fondo);

        JButton btnNueva = crearBoton("NUEVA PARTIDA");
        JButton btnConfigurar = crearBoton("CONFIGURAR");

        btnNueva.addActionListener(e -> reiniciarPartida());
        btnConfigurar.addActionListener(e -> configurarPartida());

        panelControl.add(btnNueva);
        panelControl.add(btnConfigurar);

        inferior.add(panelOpciones);
        inferior.add(panelControl);

        principal.add(inferior, BorderLayout.SOUTH);

        add(principal);
    }

    public JLabel crearEtiqueta(String texto) {

        JLabel etiqueta = new JLabel(texto, SwingConstants.CENTER);

        etiqueta.setOpaque(true);
        etiqueta.setBackground(tarjeta);
        etiqueta.setForeground(Color.WHITE);
        etiqueta.setFont(new Font("Arial", Font.BOLD, 17));

        return etiqueta;
    }

    public JButton crearBoton(String texto) {

        JButton boton = new JButton(texto);

        boton.setFont(new Font("Arial", Font.BOLD, 14));
        boton.setBackground(tarjeta);
        boton.setForeground(Color.WHITE);
        boton.setFocusPainted(false);
        boton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        boton.setBorder(
                BorderFactory.createLineBorder(azul, 2)
        );

        return boton;
    }

    public void configurarPartida() {

        String[] dificultades = {
                "Facil", "Medio", "Dificil"
        };

        int seleccion = JOptionPane.showOptionDialog(
                this,
                "Selecciona la dificultad",
                "Configuracion",
                JOptionPane.DEFAULT_OPTION,
                JOptionPane.QUESTION_MESSAGE,
                null,
                dificultades,
                dificultades[0]
        );

        if (seleccion == -1) {
            if (ronda == 0) {
                reiniciarPartida();
            }
            return;
        }

        int nuevaDificultad = seleccion + 1;

        String[] rondas = {
                "Mejor de 3", "Mejor de 5", "Mejor de 7"
        };

        int seleccionRondas = JOptionPane.showOptionDialog(
                this,
                "Selecciona la cantidad de rondas",
                "Configuracion",
                JOptionPane.DEFAULT_OPTION,
                JOptionPane.QUESTION_MESSAGE,
                null,
                rondas,
                rondas[0]
        );

        if (seleccionRondas == -1) {
            if (ronda == 0) {
                reiniciarPartida();
            }
            return;
        }

        dificultad = nuevaDificultad;
        victoriasNecesarias = seleccionRondas + 2;

        reiniciarPartida();
    }

    public void reiniciarPartida() {

        puntosJugador = 0;
        puntosComputadora = 0;
        empates = 0;
        ronda = 1;
        ultimaEleccion = 0;
        partidaTerminada = false;

        lblRonda.setText("RONDA 1");
        lblJugador.setText("TU: ?");
        lblComputadora.setText("COMPUTADORA: ?");
        lblResultado.setText("Selecciona una opcion");
        lblResultado.setForeground(azul);

        actualizarMarcador();

        btnPiedra.setEnabled(true);
        btnPapel.setEnabled(true);
        btnTijera.setEnabled(true);
    }

    public int elegirComputadora() {

        if (dificultad == 1) {
            return random.nextInt(3) + 1;
        }

        if (dificultad == 2) {

            if (ultimaEleccion != 0 && random.nextBoolean()) {
                return ultimaEleccion % 3 + 1;
            }

            return random.nextInt(3) + 1;
        }

        if (ultimaEleccion != 0) {
            return ultimaEleccion % 3 + 1;
        }

        return random.nextInt(3) + 1;
    }

    public int comprobarResultado(int jugador, int computadora) {

        if (jugador == computadora) {
            return 0;
        }

        if ((jugador == 1 && computadora == 3) ||
                (jugador == 2 && computadora == 1) ||
                (jugador == 3 && computadora == 2)) {
            return 1;
        }

        return -1;
    }

    public void jugarRonda(int jugador) {

        if (partidaTerminada) {
            return;
        }

        int computadora = elegirComputadora();
        ultimaEleccion = jugador;

        lblJugador.setText("TU: " + opciones[jugador - 1]);
        lblComputadora.setText(
                "COMPUTADORA: " + opciones[computadora - 1]
        );

        int resultado = comprobarResultado(jugador, computadora);

        if (resultado == 1) {

            puntosJugador++;
            lblResultado.setText("GANASTE ESTA RONDA");
            lblResultado.setForeground(verde);

        } else if (resultado == -1) {

            puntosComputadora++;
            lblResultado.setText("PERDISTE ESTA RONDA");
            lblResultado.setForeground(rojo);

        } else {

            empates++;
            lblResultado.setText("EMPATE");
            lblResultado.setForeground(azul);
        }

        actualizarMarcador();

        if (puntosJugador == victoriasNecesarias ||
                puntosComputadora == victoriasNecesarias) {

            finalizarPartida();
            return;
        }

        ronda++;
        lblRonda.setText("RONDA " + ronda);
    }

    public void actualizarMarcador() {

        lblMarcador.setText(
                "Jugador: " + puntosJugador
                        + " | Computadora: " + puntosComputadora
                        + " | Empates: " + empates
        );
    }

    public void finalizarPartida() {

        partidaTerminada = true;

        btnPiedra.setEnabled(false);
        btnPapel.setEnabled(false);
        btnTijera.setEnabled(false);

        if (puntosJugador > puntosComputadora) {

            estadisticas.registrarVictoria(puntosJugador * 100 + empates * 10);

            lblResultado.setText("¡GANASTE LA PARTIDA!");
            lblResultado.setForeground(verde);

            JOptionPane.showMessageDialog(
                    this,
                    "¡Felicidades! Ganaste la partida.",
                    "Victoria",
                    JOptionPane.INFORMATION_MESSAGE
            );

        } else {

            estadisticas.registrarDerrota(puntosJugador * 50 + empates * 10);

            lblResultado.setText("HAS PERDIDO LA PARTIDA");
            lblResultado.setForeground(rojo);

            JOptionPane.showMessageDialog(
                    this,
                    "La computadora ganó la partida.",
                    "Derrota",
                    JOptionPane.INFORMATION_MESSAGE
            );
        }
    }
}
