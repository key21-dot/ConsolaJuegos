package PPT;


import Base.Juegos;
import console.DisConsola;

import java.util.Scanner;
import java.util.Random;

public class JuegoPPT extends Juegos {

    private Scanner sc;
    private Random random;

    private String[] opciones = {
            "PIEDRA", "PAPEL", "TIJERA"
    };

    public JuegoPPT(Scanner sc) {
        super("Piedra, Papel o Tijera");
        this.sc = sc;
        this.random = new Random();
    }

    public void mostrarOpciones() {

        DisConsola.separador();

        System.out.println("  [1] PIEDRA");
        System.out.println("  [2] PAPEL");
        System.out.println("  [3] TIJERA");
        System.out.println("  [0] Abandonar partida");

        DisConsola.separador();
    }

    public int elegirComputadora(int dificultad,
                                 int ultimaEleccion) {

        // Facil: completamente aleatorio
        if (dificultad == 1) {
            return random.nextInt(3) + 1;
        }

        // Medio: aleatorio, pero a veces intenta
        // vencer la ultima eleccion del jugador
        if (dificultad == 2) {

            if (ultimaEleccion != 0 && random.nextBoolean()) {
                return ultimaEleccion % 3 + 1;
            }

            return random.nextInt(3) + 1;
        }

        // Dificil: intenta vencer la ultima eleccion
        if (ultimaEleccion != 0) {
            return ultimaEleccion % 3 + 1;
        }

        return random.nextInt(3) + 1;
    }

    public int comprobarResultado(int jugador,
                                  int computadora) {

        if (jugador == computadora) {
            return 0;
        }

        if ((jugador == 1 && computadora == 3) ||
                (jugador == 2 && computadora == 1) ||
                (jugador == 3 && computadora == 2)) {
            return 1;
        }

        return -1;
    }

    public void mostrarMarcador(int jugador,
                                int computadora,
                                int empates) {

        System.out.println();
        DisConsola.subtitulo("MARCADOR ACTUAL");

        System.out.println(DisConsola.VERDE
                + "  Jugador:     " + jugador
                + DisConsola.RESET);

        System.out.println(DisConsola.ROJO
                + "  Computadora: " + computadora
                + DisConsola.RESET);

        System.out.println(DisConsola.AMARILLO
                + "  Empates:     " + empates
                + DisConsola.RESET);
    }

    @Override
    public void jugar() {

        DisConsola.titulo("PIEDRA, PAPEL O TIJERA");

        System.out.println("  [1] Facil");
        System.out.println("  [2] Medio");
        System.out.println("  [3] Dificil");
        System.out.println("  [0] Regresar al menu");

        int dificultad;

        while (true) {

            System.out.print("\n>> Seleccione dificultad: ");

            if (!sc.hasNextInt()) {
                DisConsola.error("Ingrese un numero valido.");
                sc.next();
                continue;
            }

            dificultad = sc.nextInt();

            if (dificultad == 0) {
                return;
            }

            if (dificultad >= 1 && dificultad <= 3) {
                break;
            }

            DisConsola.error("Opcion invalida.");
        }

        DisConsola.subtitulo("CANTIDAD DE RONDAS");

        System.out.println("  [1] Mejor de 3");
        System.out.println("  [2] Mejor de 5");
        System.out.println("  [3] Mejor de 7");
        System.out.println("  [0] Regresar");

        int opcionRondas;

        while (true) {

            System.out.print("\n>> Seleccione una opcion: ");

            if (!sc.hasNextInt()) {
                DisConsola.error("Ingrese un numero.");
                sc.next();
                continue;
            }

            opcionRondas = sc.nextInt();

            if (opcionRondas == 0) {
                return;
            }

            if (opcionRondas >= 1 && opcionRondas <= 3) {
                break;
            }

            DisConsola.error("Opcion invalida.");
        }

        int maxRondas = opcionRondas * 2 + 1;
        int victoriasNecesarias = maxRondas / 2 + 1;

        int puntosJugador = 0;
        int puntosComputadora = 0;
        int empates = 0;
        int ultimaEleccion = 0;
        int ronda = 1;

        while (puntosJugador < victoriasNecesarias &&
                puntosComputadora < victoriasNecesarias) {

            DisConsola.titulo("RONDA " + ronda);

            mostrarMarcador(puntosJugador,
                    puntosComputadora, empates);

            mostrarOpciones();

            System.out.print(">> Tu eleccion: ");

            if (!sc.hasNextInt()) {
                DisConsola.error("Ingrese un numero.");
                sc.next();
                continue;
            }

            int jugador = sc.nextInt();

            if (jugador == 0) {
                DisConsola.mensaje("Regresando al menu...");
                return;
            }

            if (jugador < 1 || jugador > 3) {
                DisConsola.error("Opcion invalida.");
                continue;
            }

            int computadora =
                    elegirComputadora(dificultad, ultimaEleccion);

            ultimaEleccion = jugador;

            System.out.println();
            DisConsola.separador();

            System.out.println(DisConsola.VERDE
                    + "  TU ELECCION: " + opciones[jugador - 1]
                    + DisConsola.RESET);

            System.out.println(DisConsola.ROJO
                    + "  COMPUTADORA: " + opciones[computadora - 1]
                    + DisConsola.RESET);

            DisConsola.separador();

            int resultado =
                    comprobarResultado(jugador, computadora);

            if (resultado == 1) {

                puntosJugador++;
                DisConsola.exito("Ganaste esta ronda!");

            } else if (resultado == -1) {

                puntosComputadora++;
                DisConsola.error("Perdiste esta ronda!");

            } else {

                empates++;
                DisConsola.mensaje("Esta ronda fue un empate.");
            }

            ronda++;
        }

        DisConsola.titulo("RESULTADO FINAL");

        mostrarMarcador(puntosJugador,
                puntosComputadora, empates);

        if (puntosJugador > puntosComputadora) {

            DisConsola.victoria();
            getEstadistica().registrarVictoria(puntosJugador * 100 + empates * 10);

        } else {

            DisConsola.derrota();
            getEstadistica().registrarDerrota(puntosJugador * 50 + empates * 10);
        }
    }
}
