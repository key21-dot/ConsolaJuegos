package TresEnRaya;

import Base.Juegos;
import console.DisConsola;

import java.util.Scanner;
import java.util.Random;

public class Juego3LK extends Juegos {

    private Scanner sc;
    private Random random;
    private char[][] tablero;

    public Juego3LK(Scanner sc) {
        super("Tres en raya");
        this.sc = sc;
        this.random = new Random();
        this.tablero = new char[3][3];
    }

    public void iniciarTablero() {

        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                tablero[i][j] = ' ';
            }
        }
    }

    public void mostrarTablero() {

        System.out.println();
        System.out.println(DisConsola.AZUL
                + "       ╔═════╦═════╦═════╗"
                + DisConsola.RESET);

        for (int i = 0; i < 3; i++) {

            System.out.print(DisConsola.AZUL
                    + "       ║" + DisConsola.RESET);

            for (int j = 0; j < 3; j++) {

                int posicion = i * 3 + j + 1;
                char ficha = tablero[i][j];

                if (ficha == 'X') {
                    System.out.print("  " + DisConsola.VERDE
                            + "X" + DisConsola.RESET + "  ");
                } else if (ficha == 'O') {
                    System.out.print("  " + DisConsola.ROJO
                            + "O" + DisConsola.RESET + "  ");
                } else {
                    System.out.print("  " + posicion + "  ");
                }

                System.out.print(DisConsola.AZUL
                        + "║" + DisConsola.RESET);
            }

            System.out.println();

            if (i < 2) {
                System.out.println(DisConsola.AZUL
                        + "       ╠═════╬═════╬═════╣"
                        + DisConsola.RESET);
            }
        }

        System.out.println(DisConsola.AZUL
                + "       ╚═════╩═════╩═════╝"
                + DisConsola.RESET);

        System.out.println();
    }

    public boolean movimientoValido(int posicion) {

        if (posicion < 1 || posicion > 9) {
            return false;
        }

        int fila = (posicion - 1) / 3;
        int columna = (posicion - 1) % 3;

        return tablero[fila][columna] == ' ';
    }

    public void colocarFicha(int posicion, char ficha) {

        int fila = (posicion - 1) / 3;
        int columna = (posicion - 1) % 3;

        tablero[fila][columna] = ficha;
    }

    public boolean verificarGanador(char ficha) {

        for (int i = 0; i < 3; i++) {

            if (tablero[i][0] == ficha &&
                    tablero[i][1] == ficha &&
                    tablero[i][2] == ficha) {
                return true;
            }

            if (tablero[0][i] == ficha &&
                    tablero[1][i] == ficha &&
                    tablero[2][i] == ficha) {
                return true;
            }
        }

        if (tablero[0][0] == ficha &&
                tablero[1][1] == ficha &&
                tablero[2][2] == ficha) {
            return true;
        }

        if (tablero[0][2] == ficha &&
                tablero[1][1] == ficha &&
                tablero[2][0] == ficha) {
            return true;
        }

        return false;
    }

    public boolean tableroLleno() {

        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {

                if (tablero[i][j] == ' ') {
                    return false;
                }
            }
        }

        return true;
    }

    public int buscarMovimiento(char ficha) {

        for (int posicion = 1; posicion <= 9; posicion++) {

            if (movimientoValido(posicion)) {

                colocarFicha(posicion, ficha);

                boolean gana = verificarGanador(ficha);

                colocarFicha(posicion, ' ');

                if (gana) {
                    return posicion;
                }
            }
        }

        return -1;
    }

    public void turnoComputadora(int dificultad) {

        int posicion = -1;

        if (dificultad == 2) {

            posicion = buscarMovimiento('O');

            if (posicion == -1) {
                posicion = buscarMovimiento('X');
            }

            if (posicion == -1 && movimientoValido(5)) {
                posicion = 5;
            }

            if (posicion == -1) {

                int[] esquinas = {1, 3, 7, 9};

                for (int esquina : esquinas) {

                    if (movimientoValido(esquina)) {
                        posicion = esquina;
                        break;
                    }
                }
            }
        }

        if (posicion == -1) {

            do {
                posicion = random.nextInt(9) + 1;
            } while (!movimientoValido(posicion));
        }

        colocarFicha(posicion, 'O');

        DisConsola.mensaje(
                "La computadora eligio la casilla " + posicion);
    }

    @Override
    public void jugar() {

        iniciarTablero();

        DisConsola.titulo("TRES EN RAYA");

        System.out.println("  [1] Facil");
        System.out.println("  [2] Dificil");
        System.out.println("  [0] Regresar");

        int dificultad;

        while (true) {

            System.out.print("\n>> Dificultad: ");

            if (!sc.hasNextInt()) {
                DisConsola.error("Ingrese un numero.");
                sc.next();
                continue;
            }

            dificultad = sc.nextInt();

            if (dificultad == 0) {
                return;
            }

            if (dificultad == 1 || dificultad == 2) {
                break;
            }

            DisConsola.error("Opcion invalida.");
        }

        while (true) {

            DisConsola.titulo("PARTIDA DE TRES EN RAYA");

            System.out.println(DisConsola.AZUL
                    + "  JUGADOR: X" + DisConsola.RESET);

            System.out.println(DisConsola.ROJO
                    + "  COMPUTADORA: O" + DisConsola.RESET);

            mostrarTablero();

            System.out.println("  [0] Abandonar partida");
            System.out.print("\n>> Seleccione una casilla: ");

            if (!sc.hasNextInt()) {
                DisConsola.error("Ingrese un numero.");
                sc.next();
                continue;
            }

            int posicion = sc.nextInt();

            if (posicion == 0) {
                DisConsola.mensaje("Regresando al menu...");
                return;
            }

            if (!movimientoValido(posicion)) {
                DisConsola.error("Casilla ocupada o invalida.");
                continue;
            }

            colocarFicha(posicion, 'X');

            if (verificarGanador('X')) {

                mostrarTablero();
                DisConsola.victoria();

                getEstadistica().registrarVictoria(200 + dificultad * 100);
                return;
            }

            if (tableroLleno()) {

                mostrarTablero();
                DisConsola.empate();

                getEstadistica().registrarEmpate(100);
                return;
            }

            turnoComputadora(dificultad);

            if (verificarGanador('O')) {

                mostrarTablero();
                DisConsola.derrota();

                getEstadistica().registrarDerrota(0);
                return;
            }

            if (tableroLleno()) {

                mostrarTablero();
                DisConsola.empate();

                getEstadistica().registrarEmpate(100);
                return;
            }
        }
    }
}
