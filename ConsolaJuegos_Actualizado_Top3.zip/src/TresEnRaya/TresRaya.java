package TresEnRaya;


import Base.Jugable;
import Base.Estadisticas;
import Base.RegistroEstadisticas;

public class TresRaya implements Jugable {

    private Estadisticas estadisticas;

    public TresRaya() {
        estadisticas = RegistroEstadisticas.tresRaya();
    }

    @Override
    public String getNombre() {
        return "Tres en Raya";
    }

    @Override
    public void star() {
        new VentanaTresRaya(estadisticas);
    }

    public Estadisticas getEstadisticas() {
        return estadisticas;
    }
}
