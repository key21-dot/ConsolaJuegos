package TresEnRaya;

import Base.Estadisticas;
import javax.swing.*;
import java.awt.*;
import java.util.Random;

public class VentanaTresRaya extends JFrame {

    private JButton[][] botones;
    private char[][] tablero;
    private JLabel lblEstado;
    private JLabel lblMarcador;

    private Random random;
    private Estadisticas estadisticas;

    private int dificultad;
    private int victorias;
    private int derrotas;
    private int empates;

    private boolean partidaTerminada;

    private Color fondo = new Color(15, 23, 42);
    private Color tarjeta = new Color(30, 41, 59);
    private Color azul = new Color(34, 211, 238);

    public VentanaTresRaya(Estadisticas estadisticas) {

        this.estadisticas = estadisticas;
        this.random = new Random();

        botones = new JButton[3][3];
        tablero = new char[3][3];

        setTitle("GameConsole - Tres en Raya");
        setSize(480, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);

        crearInterfaz();
        seleccionarDificultad();

        setVisible(true);
    }

    public void crearInterfaz() {

        JPanel principal = new JPanel(new BorderLayout(15, 15));
        principal.setBackground(fondo);
        principal.setBorder(
                BorderFactory.createEmptyBorder(20, 25, 20, 25)
        );

        JLabel titulo = new JLabel(
                "TRES EN RAYA", SwingConstants.CENTER
        );

        titulo.setFont(new Font("Arial", Font.BOLD, 28));
        titulo.setForeground(azul);

        principal.add(titulo, BorderLayout.NORTH);

        JPanel panelTablero = new JPanel(new GridLayout(3, 3, 8, 8));
        panelTablero.setBackground(fondo);

        for (int i = 0; i < 3; i++) {

            for (int j = 0; j < 3; j++) {

                final int fila = i;
                final int columna = j;

                JButton boton = new JButton("");

                boton.setFont(new Font("Arial", Font.BOLD, 55));
                boton.setBackground(tarjeta);
                boton.setForeground(Color.WHITE);
                boton.setFocusPainted(false);
                boton.setCursor(new Cursor(Cursor.HAND_CURSOR));

                boton.addActionListener(e ->
                        turnoJugador(fila, columna));

                botones[i][j] = boton;
                panelTablero.add(boton);
            }
        }

        principal.add(panelTablero, BorderLayout.CENTER);

        JPanel panelInferior = new JPanel(new GridLayout(4, 1, 8, 8));
        panelInferior.setBackground(fondo);

        lblEstado = new JLabel(
                "Tu turno: X", SwingConstants.CENTER
        );

        lblEstado.setForeground(Color.WHITE);
        lblEstado.setFont(new Font("Arial", Font.BOLD, 17));

        lblMarcador = new JLabel(
                "Victorias: 0 | Derrotas: 0 | Empates: 0",
                SwingConstants.CENTER
        );

        lblMarcador.setForeground(azul);

        JButton btnReiniciar = new JButton("NUEVA PARTIDA");
        btnReiniciar.addActionListener(e -> reiniciarPartida());

        JButton btnDificultad = new JButton("CAMBIAR DIFICULTAD");
        btnDificultad.addActionListener(e -> seleccionarDificultad());

        panelInferior.add(lblEstado);
        panelInferior.add(lblMarcador);
        panelInferior.add(btnReiniciar);
        panelInferior.add(btnDificultad);

        principal.add(panelInferior, BorderLayout.SOUTH);

        add(principal);
    }

    public void seleccionarDificultad() {

        String[] opciones = {"Facil", "Dificil"};

        int seleccion = JOptionPane.showOptionDialog(
                this,
                "Selecciona la dificultad",
                "Tres en Raya",
                JOptionPane.DEFAULT_OPTION,
                JOptionPane.QUESTION_MESSAGE,
                null,
                opciones,
                opciones[0]
        );

        if (seleccion == 0) {
            dificultad = 1;
        } else if (seleccion == 1) {
            dificultad = 2;
        } else {
            if (dificultad == 0) {
                dificultad = 1;
            }
        }

        reiniciarPartida();
    }

    public void reiniciarPartida() {

        partidaTerminada = false;

        for (int i = 0; i < 3; i++) {

            for (int j = 0; j < 3; j++) {

                tablero[i][j] = ' ';
                botones[i][j].setText("");
                botones[i][j].setEnabled(true);
            }
        }

        lblEstado.setText("Tu turno: X");
    }

    public void turnoJugador(int fila, int columna) {

        if (partidaTerminada || tablero[fila][columna] != ' ') {
            return;
        }

        colocarFicha(fila, columna, 'X');

        if (comprobarFinal('X')) {
            return;
        }

        turnoComputadora();
    }

    public void colocarFicha(int fila, int columna, char ficha) {

        tablero[fila][columna] = ficha;

        botones[fila][columna].setText(String.valueOf(ficha));

        if (ficha == 'X') {
            botones[fila][columna].setForeground(
                    new Color(74, 222, 128)
            );
        } else {
            botones[fila][columna].setForeground(
                    new Color(251, 113, 133)
            );
        }
    }

    public void turnoComputadora() {

        int posicion = -1;

        if (dificultad == 2) {

            posicion = buscarMovimiento('O');

            if (posicion == -1) {
                posicion = buscarMovimiento('X');
            }

            if (posicion == -1 && tablero[1][1] == ' ') {
                posicion = 4;
            }
        }

        if (posicion == -1) {

            do {
                posicion = random.nextInt(9);
            } while (tablero[posicion / 3][posicion % 3] != ' ');
        }

        colocarFicha(posicion / 3, posicion % 3, 'O');

        comprobarFinal('O');
    }

    public int buscarMovimiento(char ficha) {

        for (int posicion = 0; posicion < 9; posicion++) {

            int fila = posicion / 3;
            int columna = posicion % 3;

            if (tablero[fila][columna] == ' ') {

                tablero[fila][columna] = ficha;

                boolean gana = verificarGanador(ficha);

                tablero[fila][columna] = ' ';

                if (gana) {
                    return posicion;
                }
            }
        }

        return -1;
    }

    public boolean verificarGanador(char ficha) {

        for (int i = 0; i < 3; i++) {

            if (tablero[i][0] == ficha &&
                    tablero[i][1] == ficha &&
                    tablero[i][2] == ficha) {
                return true;
            }

            if (tablero[0][i] == ficha &&
                    tablero[1][i] == ficha &&
                    tablero[2][i] == ficha) {
                return true;
            }
        }

        if (tablero[0][0] == ficha &&
                tablero[1][1] == ficha &&
                tablero[2][2] == ficha) {
            return true;
        }

        if (tablero[0][2] == ficha &&
                tablero[1][1] == ficha &&
                tablero[2][0] == ficha) {
            return true;
        }

        return false;
    }

    public boolean tableroLleno() {

        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {

                if (tablero[i][j] == ' ') {
                    return false;
                }
            }
        }

        return true;
    }

    public boolean comprobarFinal(char ficha) {

        if (verificarGanador(ficha)) {

            partidaTerminada = true;

            if (ficha == 'X') {

                victorias++;
                estadisticas.registrarVictoria(200 + dificultad * 100);

                lblEstado.setText("¡GANASTE!");

                JOptionPane.showMessageDialog(
                        this, "¡Felicidades! Has ganado."
                );

            } else {

                derrotas++;
                estadisticas.registrarDerrota(0);

                lblEstado.setText("HAS PERDIDO");

                JOptionPane.showMessageDialog(
                        this, "La computadora ha ganado."
                );
            }

            actualizarMarcador();
            desactivarTablero();

            return true;
        }

        if (tableroLleno()) {

            partidaTerminada = true;

            empates++;
            estadisticas.registrarEmpate(100);

            lblEstado.setText("EMPATE");

            JOptionPane.showMessageDialog(
                    this, "La partida terminó en empate."
            );

            actualizarMarcador();
            desactivarTablero();

            return true;
        }

        return false;
    }

    public void actualizarMarcador() {

        lblMarcador.setText(
                "Victorias: " + victorias
                        + " | Derrotas: " + derrotas
                        + " | Empates: " + empates
        );
    }

    public void desactivarTablero() {

        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                botones[i][j].setEnabled(false);
            }
        }
    }
}
