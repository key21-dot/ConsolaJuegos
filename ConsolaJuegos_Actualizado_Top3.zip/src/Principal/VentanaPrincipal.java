
package Principal;

import Ahorcado.Ahorcado;
import TresEnRaya.TresRaya;
import PPT.PPT;
import Base.RegistroEstadisticas;

import javax.swing.*;
import java.awt.*;

public class VentanaPrincipal extends JFrame {

    private JPanel panelPrincipal;

    // Colores de GameConsole
    private Color fondo = new Color(15, 23, 42);
    private Color tarjeta = new Color(30, 41, 59);
    private Color azul = new Color(34, 211, 238);
    private Color blanco = Color.WHITE;

    // Base.Juegos independientes
    private Ahorcado ahorcado = new Ahorcado();
    private TresRaya tresRaya = new TresRaya();
    private PPT ppt = new PPT();

    public VentanaPrincipal() {

        setTitle("GameConsole - Java Edition");
        setSize(750, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);

        String nombre = JOptionPane.showInputDialog(this,
                "Nombre del jugador para el ranking:", "Keylor");
        if (nombre == null || nombre.trim().isEmpty()) nombre = "Jugador";
        RegistroEstadisticas.ahorcado().setJugadorActual(nombre);
        RegistroEstadisticas.tresRaya().setJugadorActual(nombre);
        RegistroEstadisticas.ppt().setJugadorActual(nombre);
        crearInterfaz();

        setVisible(true);
    }

    public void crearInterfaz() {

        panelPrincipal = new JPanel(new BorderLayout(15, 15));
        panelPrincipal.setBackground(fondo);

        panelPrincipal.setBorder(
                BorderFactory.createEmptyBorder(30, 35, 30, 35)
        );

        // ENCABEZADO
        JPanel encabezado = new JPanel(new GridLayout(2, 1));
        encabezado.setBackground(fondo);

        JLabel titulo = new JLabel(
                "GAME CONSOLE", SwingConstants.CENTER
        );

        titulo.setFont(new Font("Arial", Font.BOLD, 36));
        titulo.setForeground(azul);

        JLabel subtitulo = new JLabel(
                "JAVA EDITION - CENTRO DE JUEGOS",
                SwingConstants.CENTER
        );

        subtitulo.setFont(new Font("Arial", Font.PLAIN, 14));
        subtitulo.setForeground(Color.LIGHT_GRAY);

        encabezado.add(titulo);
        encabezado.add(subtitulo);

        panelPrincipal.add(encabezado, BorderLayout.NORTH);

        // PANEL DE JUEGOS
        JPanel panelJuegos = new JPanel(new GridLayout(2, 2, 20, 20));
        panelJuegos.setBackground(fondo);

        JButton btnAhorcado = crearBoton(
                "AHORCADO", "Adivina la palabra"
        );

        JButton btnTresRaya = crearBoton(
                "TRES EN RAYA", "Jugador contra computadora"
        );

        JButton btnPPT = crearBoton(
                "PIEDRA, PAPEL O TIJERA",
                "Desafia a la computadora"
        );

        JButton btnEstadisticas = crearBoton(
                "ESTADISTICAS", "Consulta tus resultados"
        );

        panelJuegos.add(btnAhorcado);
        panelJuegos.add(btnTresRaya);
        panelJuegos.add(btnPPT);
        panelJuegos.add(btnEstadisticas);

        panelPrincipal.add(panelJuegos, BorderLayout.CENTER);

        // ABRIR AHORCADO
        btnAhorcado.addActionListener(e -> {
            ahorcado.star();
        });

        // ABRIR TRES EN RAYA
        btnTresRaya.addActionListener(e -> {
            tresRaya.star();
        });

        // ABRIR PIEDRA, PAPEL O TIJERA
        btnPPT.addActionListener(e -> {
            ppt.star();
        });

        // MOSTRAR ESTADISTICAS
        btnEstadisticas.addActionListener(e -> {

            String mensaje =
                    "AHORCADO\n"
                            + ahorcado.getEstadisticas()
                            + "\n\n"
                            + "TRES EN RAYA\n"
                            + tresRaya.getEstadisticas()
                            + "\n\n"
                            + "PIEDRA, PAPEL O TIJERA\n"
                            + ppt.getEstadisticas();

            JTextArea area = new JTextArea(mensaje, 24, 52);
            area.setEditable(false);
            area.setFont(new Font("Monospaced", Font.PLAIN, 13));
            area.setCaretPosition(0);
            JOptionPane.showMessageDialog(this, new JScrollPane(area),
                    "Estadisticas y Top 3 - GameConsole", JOptionPane.INFORMATION_MESSAGE);
        });

        // PANEL INFERIOR
        JPanel pie = new JPanel(new BorderLayout(15, 10));
        pie.setBackground(fondo);

        JLabel mensaje = new JLabel(
                "Selecciona un juego para comenzar",
                SwingConstants.CENTER
        );

        mensaje.setForeground(Color.LIGHT_GRAY);
        mensaje.setFont(new Font("Arial", Font.PLAIN, 13));

        // NOMBRE DEL DESARROLLADOR
        JLabel creador = new JLabel(
                "Desarrollado por: Keylor Alonso Lopez Obando",
                SwingConstants.CENTER
        );

        creador.setFont(new Font("Arial", Font.BOLD, 13));
        creador.setForeground(azul);

        JButton btnSalir = new JButton("SALIR");

        btnSalir.setBackground(new Color(185, 28, 28));
        btnSalir.setForeground(blanco);
        btnSalir.setFocusPainted(false);
        btnSalir.setCursor(new Cursor(Cursor.HAND_CURSOR));

        btnSalir.addActionListener(e -> System.exit(0));

        JPanel textos = new JPanel(new GridLayout(2, 1, 5, 5));
        textos.setBackground(fondo);

        textos.add(mensaje);
        textos.add(creador);

        pie.add(textos, BorderLayout.CENTER);
        pie.add(btnSalir, BorderLayout.EAST);

        panelPrincipal.add(pie, BorderLayout.SOUTH);

        add(panelPrincipal);
    }

    public JButton crearBoton(String nombre, String descripcion) {

        JButton boton = new JButton(
                "<html><center>"
                        + nombre
                        + "<br><br>"
                        + "<font size='3'>"
                        + descripcion
                        + "</font></center></html>"
        );

        boton.setFont(new Font("Arial", Font.BOLD, 16));
        boton.setBackground(tarjeta);
        boton.setForeground(blanco);
        boton.setFocusPainted(false);

        boton.setCursor(
                new Cursor(Cursor.HAND_CURSOR)
        );

        boton.setBorder(
                BorderFactory.createLineBorder(azul, 2)
        );

        return boton;
    }
}
