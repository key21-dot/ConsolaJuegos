package console;


public class DisConsola {

    public static final String RESET = "\u001B[0m";
    public static final String AZUL = "\u001B[36m";
    public static final String VERDE = "\u001B[32m";
    public static final String ROJO = "\u001B[31m";
    public static final String AMARILLO = "\u001B[33m";
    public static final String MORADO = "\u001B[35m";
    public static final String BLANCO = "\u001B[37m";

    public static void titulo(String texto) {
        System.out.println();
        System.out.println(AZUL
                + "╔════════════════════════════════════════╗"
                + RESET);
        System.out.printf(MORADO + "║ %-38s ║%n" + RESET, texto);
        System.out.println(AZUL
                + "╚════════════════════════════════════════╝"
                + RESET);
    }

    public static void separador() {
        System.out.println(AZUL
                + "──────────────────────────────────────────"
                + RESET);
    }

    public static void mensaje(String texto) {
        System.out.println(AMARILLO + "➜ " + texto + RESET);
    }

    public static void error(String texto) {
        System.out.println(ROJO + "[!] " + texto + RESET);
    }

    public static void exito(String texto) {
        System.out.println(VERDE + "[✓] " + texto + RESET);
    }

    public static void victoria() {
        System.out.println();
        System.out.println(VERDE
                + "╔════════════════════════════════════════╗");
        System.out.println("║              FELICIDADES               ║");
        System.out.println("║               HAS GANADO               ║");
        System.out.println("╚════════════════════════════════════════╝"
                + RESET);
    }

    public static void derrota() {
        System.out.println();
        System.out.println(ROJO
                + "╔════════════════════════════════════════╗");
        System.out.println("║              FIN DEL JUEGO             ║");
        System.out.println("║               HAS PERDIDO              ║");
        System.out.println("╚════════════════════════════════════════╝"
                + RESET);
    }

    public static void empate() {
        System.out.println();
        System.out.println(AMARILLO
                + "╔════════════════════════════════════════╗");
        System.out.println("║                 EMPATE                 ║");
        System.out.println("╚════════════════════════════════════════╝"
                + RESET);
    }

    public static void barraProgreso(int actual, int maximo) {
        int bloques = 20;
        int llenos = actual * bloques / maximo;

        System.out.print("  [");

        for (int i = 0; i < bloques; i++) {
            if (i < llenos) {
                System.out.print(VERDE + "■" + RESET);
            } else {
                System.out.print("□");
            }
        }

        System.out.println("] " + actual + "/" + maximo);
    }

    public static void mostrarIntentos(int errores, int maximo) {
        System.out.print("  INTENTOS: ");

        for (int i = 0; i < maximo; i++) {
            if (i < maximo - errores) {
                System.out.print(VERDE + "♥ " + RESET);
            } else {
                System.out.print(ROJO + "♡ " + RESET);
            }
        }

        System.out.println();
    }

    public static void subtitulo(String texto) {
        System.out.println();
        System.out.println(MORADO + "  » " + texto + RESET);
        separador();
    }

    public static void menuPrincipal() {
        titulo("GAME CONSOLE");

        System.out.println(AZUL
                + "          JAVA CONSOLE EDITION"
                + RESET);

        System.out.println();
        System.out.println("  [1] Ver juegos disponibles");
        System.out.println("  [2] Iniciar partida");
        System.out.println("  [3] Estadisticas y Top 3");
        System.out.println("  [4] Salir");

        separador();
        System.out.print(AZUL
                + "  ➜ Selecciona una opcion: "
                + RESET);
    }
}
