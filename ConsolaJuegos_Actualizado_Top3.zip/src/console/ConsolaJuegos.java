package console;


import Ahorcado.JuegoAhorK;
import Base.Juegos;
import Base.RegistroEstadisticas;
import PPT.JuegoPPT;
import TresEnRaya.Juego3LK;

import java.util.Scanner;

public class ConsolaJuegos {

    private Scanner sc;
    private Juegos[] juegos;

    public ConsolaJuegos() {

        sc = new Scanner(System.in);
        System.out.print("Nombre del jugador: ");
        String nombre = sc.nextLine().trim();
        if (nombre.isEmpty()) nombre = "Jugador";
        RegistroEstadisticas.ahorcado().setJugadorActual(nombre);
        RegistroEstadisticas.tresRaya().setJugadorActual(nombre);
        RegistroEstadisticas.ppt().setJugadorActual(nombre);

        juegos = new Juegos[3];

        juegos[0] = new JuegoAhorK(sc);
        juegos[1] = new Juego3LK(sc);
        juegos[2] = new JuegoPPT(sc);
    }

    public void mostrarJuegos() {

        DisConsola.titulo("JUEGOS DISPONIBLES");

        for (int i = 0; i < juegos.length; i++) {
            System.out.println("  [" + (i + 1) + "] "
                    + juegos[i].getNombre());
        }

        DisConsola.separador();
    }

    public void lanzarJuego() {

        mostrarJuegos();

        System.out.println("  [0] Regresar al menu");
        System.out.print("\n>> Seleccione un juego: ");

        if (!sc.hasNextInt()) {
            DisConsola.error("Ingrese un numero valido.");
            sc.next();
            return;
        }

        int opcion = sc.nextInt();

        if (opcion == 0) {
            return;
        }

        if (opcion >= 1 && opcion <= juegos.length) {

            juegos[opcion - 1].star();

        } else {

            DisConsola.error("Juego no disponible.");
        }
    }

    public void mostrarEstadisticas() {

        DisConsola.titulo("ESTADISTICAS");

        for (Juegos juego : juegos) {

            System.out.println();
            System.out.println("  JUEGO: " + juego.getNombre());

            DisConsola.separador();

            System.out.println(juego.getEstadistica());

            DisConsola.separador();
        }
    }

    public void iniciar() {

        int opcion = 0;

        do {

            DisConsola.menuPrincipal();

            if (!sc.hasNextInt()) {

                DisConsola.error("Ingrese un numero valido.");
                sc.next();
                continue;
            }

            opcion = sc.nextInt();

            switch (opcion) {

                case 1:
                    mostrarJuegos();
                    break;

                case 2:
                    lanzarJuego();
                    break;

                case 3:
                    mostrarEstadisticas();
                    break;

                case 4:
                    DisConsola.exito(
                            "Gracias por jugar. Hasta pronto!");
                    break;

                default:
                    DisConsola.error("Opcion invalida.");
            }

        } while (opcion != 4);
    }
}
