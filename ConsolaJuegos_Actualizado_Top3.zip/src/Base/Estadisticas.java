package Base;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Estadisticas compartidas y ranking de cada juego. */
public class Estadisticas {
    private int partidasJugadas, victorias, derrotas, empates;
    private final ArrayList<Puntuacion> puntuaciones = new ArrayList<>();
    private String jugadorActual = "Jugador";

    public void setJugadorActual(String nombre) {
        if (nombre != null && !nombre.trim().isEmpty()) jugadorActual = nombre.trim();
    }
    public String getJugadorActual() { return jugadorActual; }

    public void registrarVictoria() { registrarVictoria(100); }
    public void registrarDerrota() { registrarDerrota(0); }
    public void registrarEmpate() { registrarEmpate(50); }
    public void registrarVictoria(int puntos) { registrar("Victoria", puntos); victorias++; }
    public void registrarDerrota(int puntos) { registrar("Derrota", puntos); derrotas++; }
    public void registrarEmpate(int puntos) { registrar("Empate", puntos); empates++; }

    private void registrar(String resultado, int puntos) {
        partidasJugadas++;
        puntuaciones.add(new Puntuacion(jugadorActual, puntos, resultado, false));
        Collections.sort(puntuaciones);
    }
    public void agregarEjemplo(String nombre, int puntos) {
        puntuaciones.add(new Puntuacion(nombre, puntos, "Demostracion", true));
        Collections.sort(puntuaciones);
    }
    public List<Puntuacion> getTop3() {
        return new ArrayList<>(puntuaciones.subList(0, Math.min(3, puntuaciones.size())));
    }
    public int getPartidasJugadas() { return partidasJugadas; }
    public int getVictorias() { return victorias; }
    public int getDerrotas() { return derrotas; }
    public int getEmpates() { return empates; }
    public double calcularPorcentaje() {
        return partidasJugadas == 0 ? 0 : victorias * 100.0 / partidasJugadas;
    }
    public String mostrarTop3() {
        StringBuilder sb = new StringBuilder("TOP 3 (incluye datos ficticios de demostracion):\n");
        List<Puntuacion> top = getTop3();
        if (top.isEmpty()) return "Todavia no hay puntuaciones.";
        for (int i = 0; i < top.size(); i++) sb.append("  ").append(i + 1).append(". ").append(top.get(i)).append("\n");
        return sb.toString();
    }
    @Override
    public String toString() {
        return "  Partidas jugadas: " + partidasJugadas
                + "\n  Victorias: " + victorias
                + "\n  Derrotas: " + derrotas
                + "\n  Empates: " + empates
                + "\n  Porcentaje de victorias: "
                + String.format("%.2f", calcularPorcentaje()) + "%\n"
                + mostrarTop3();
    }
}
