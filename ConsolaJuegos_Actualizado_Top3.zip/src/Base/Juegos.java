package Base;

public abstract class Juegos implements Jugable {

    private String nombre;
    private Estadisticas estadistica;

    public Juegos(String nombre) {
        this.nombre = nombre;
        if (nombre.toLowerCase().contains("ahorcado")) this.estadistica = RegistroEstadisticas.ahorcado();
        else if (nombre.toLowerCase().contains("raya")) this.estadistica = RegistroEstadisticas.tresRaya();
        else this.estadistica = RegistroEstadisticas.ppt();
    }

    public String getNombre() {
        return nombre;
    }

    public Estadisticas getEstadistica() {
        return estadistica;
    }

    @Override
    public void star() {
        jugar();
    }

    public abstract void jugar();

    @Override
    public String toString() {
        return nombre;
    }
}
