package Base;

public interface Jugable {

    String getNombre();

    void star();

}
