package Base;

/** Un solo registro compartido por los juegos graficos y de consola. */
public final class RegistroEstadisticas {
    private static final Estadisticas AHORCADO = new Estadisticas();
    private static final Estadisticas TRES_RAYA = new Estadisticas();
    private static final Estadisticas PPT = new Estadisticas();
    static {
        AHORCADO.agregarEjemplo("Ana", 950);
        AHORCADO.agregarEjemplo("Luis", 800);
        AHORCADO.agregarEjemplo("Maria", 650);
        TRES_RAYA.agregarEjemplo("Carlos", 300);
        TRES_RAYA.agregarEjemplo("Sofia", 200);
        TRES_RAYA.agregarEjemplo("Pedro", 150);
        PPT.agregarEjemplo("Laura", 500);
        PPT.agregarEjemplo("Daniel", 400);
        PPT.agregarEjemplo("Mario", 300);
    }
    private RegistroEstadisticas() { }
    public static Estadisticas ahorcado() { return AHORCADO; }
    public static Estadisticas tresRaya() { return TRES_RAYA; }
    public static Estadisticas ppt() { return PPT; }
}
