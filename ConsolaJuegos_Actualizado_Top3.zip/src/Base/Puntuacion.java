package Base;

/** Puntuacion de una partida. Comparable ordena de mayor a menor. */
public class Puntuacion implements Comparable<Puntuacion> {
    private final String jugador;
    private final int puntos;
    private final String resultado;
    private final boolean ejemplo;

    public Puntuacion(String jugador, int puntos, String resultado, boolean ejemplo) {
        this.jugador = jugador;
        this.puntos = Math.max(0, puntos);
        this.resultado = resultado;
        this.ejemplo = ejemplo;
    }
    public String getJugador() { return jugador; }
    public int getPuntos() { return puntos; }
    public String getResultado() { return resultado; }
    public boolean esEjemplo() { return ejemplo; }

    @Override
    public int compareTo(Puntuacion otra) {
        int comparacion = Integer.compare(otra.puntos, this.puntos);
        return comparacion != 0 ? comparacion : jugador.compareToIgnoreCase(otra.jugador);
    }
    @Override
    public String toString() {
        return jugador + " - " + puntos + " puntos (" + resultado + ")"
                + (ejemplo ? " [EJEMPLO]" : "");
    }
}
