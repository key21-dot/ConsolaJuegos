package gameconsole;

import console.ConsolaJuegos;

/** Ejecutar esta clase para usar el menu de texto en lugar de Swing. */
public class MainConsola {
    public static void main(String[] args) {
        new ConsolaJuegos().iniciar();
    }
}
