package Ahorcado;


import Base.Estadisticas;
import Base.RegistroEstadisticas;
import Base.Jugable;

public class Ahorcado implements Jugable {

    private Estadisticas estadisticas;

    public Ahorcado() {
        estadisticas = RegistroEstadisticas.ahorcado();
    }

    @Override
    public String getNombre() {
        return "Ahorcado";
    }

    @Override
    public void star() {
        new VentanaAhorcado(estadisticas);
    }

    public Estadisticas getEstadisticas() {
        return estadisticas;
    }
}
