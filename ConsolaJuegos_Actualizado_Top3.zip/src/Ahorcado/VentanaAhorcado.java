package Ahorcado;

import Base.Estadisticas;
import javax.swing.*;
import java.awt.*;
import java.util.Random;

public class VentanaAhorcado extends JFrame {

    private Estadisticas estadisticas;
    private Random random;

    private JLabel lblPista;
    private JLabel lblPalabra;
    private JLabel lblIntentos;
    private JLabel lblEstado;
    private JProgressBar barraProgreso;
    private JPanel panelTeclado;
    private JPanel panelDibujo;

    private String palabra;
    private String pista;
    private boolean[] descubiertas;

    private int errores;
    private int dificultad = 1;
    private boolean partidaTerminada;

    private Color fondo = new Color(15, 23, 42);
    private Color tarjeta = new Color(30, 41, 59);
    private Color azul = new Color(34, 211, 238);
    private Color verde = new Color(74, 222, 128);
    private Color rojo = new Color(251, 113, 133);

    private String[][] palabras = {
            {"GATO", "PERRO", "CASA", "LUNA", "FLOR"},
            {"TECLADO", "PLANETA", "ESCUELA", "VENTANA", "COMPUTADORA"},
            {"PROGRAMACION", "INTELIGENCIA", "ARQUITECTURA",
                    "TECNOLOGIA", "UNIVERSIDAD"}
    };

    private String[][] pistas = {
            {"Animal que maulla", "El mejor amigo del hombre",
                    "Lugar donde vivimos", "Satelite natural de la Tierra",
                    "Parte de una planta"},

            {"Dispositivo para escribir", "Gira alrededor de una estrella",
                    "Lugar donde estudiamos", "Permite ver hacia el exterior",
                    "Maquina que procesa informacion"},

            {"Creacion de programas informaticos",
                    "Capacidad de aprender y comprender",
                    "Diseno de edificios",
                    "Aplicacion practica de conocimientos",
                    "Institucion de educacion superior"}
    };

    public VentanaAhorcado(Estadisticas estadisticas) {

        this.estadisticas = estadisticas;
        this.random = new Random();

        setTitle("GameConsole - Ahorcado");
        setSize(750, 750);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);

        crearInterfaz();
        seleccionarDificultad();

        setVisible(true);
    }

    public void crearInterfaz() {

        JPanel principal = new JPanel(new BorderLayout(15, 15));
        principal.setBackground(fondo);
        principal.setBorder(
                BorderFactory.createEmptyBorder(20, 25, 20, 25)
        );

        JLabel titulo = new JLabel(
                "AHORCADO", SwingConstants.CENTER
        );

        titulo.setFont(new Font("Arial", Font.BOLD, 30));
        titulo.setForeground(azul);

        principal.add(titulo, BorderLayout.NORTH);

        // PANEL CENTRAL
        JPanel centro = new JPanel(new BorderLayout(10, 10));
        centro.setBackground(fondo);

        panelDibujo = new JPanel() {

            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                dibujarAhorcado(g);
            }
        };

        panelDibujo.setBackground(tarjeta);
        panelDibujo.setPreferredSize(new Dimension(350, 260));

        centro.add(panelDibujo, BorderLayout.NORTH);

        JPanel panelInformacion = new JPanel(new GridLayout(4, 1, 5, 5));
        panelInformacion.setBackground(fondo);

        lblPista = new JLabel("", SwingConstants.CENTER);
        lblPista.setForeground(Color.WHITE);

        lblPalabra = new JLabel("", SwingConstants.CENTER);
        lblPalabra.setFont(new Font("Arial", Font.BOLD, 27));
        lblPalabra.setForeground(verde);

        lblIntentos = new JLabel("", SwingConstants.CENTER);
        lblIntentos.setForeground(rojo);

        barraProgreso = new JProgressBar(0, 100);
        barraProgreso.setStringPainted(true);
        barraProgreso.setForeground(verde);

        panelInformacion.add(lblPista);
        panelInformacion.add(lblPalabra);
        panelInformacion.add(lblIntentos);
        panelInformacion.add(barraProgreso);

        centro.add(panelInformacion, BorderLayout.CENTER);

        principal.add(centro, BorderLayout.CENTER);

        // PANEL INFERIOR
        JPanel inferior = new JPanel(new BorderLayout(10, 10));
        inferior.setBackground(fondo);

        panelTeclado = new JPanel(new GridLayout(3, 9, 5, 5));
        panelTeclado.setBackground(fondo);

        inferior.add(panelTeclado, BorderLayout.CENTER);

        JPanel panelControles = new JPanel(new GridLayout(2, 1, 5, 5));
        panelControles.setBackground(fondo);

        lblEstado = new JLabel(
                "Selecciona una letra", SwingConstants.CENTER
        );

        lblEstado.setForeground(Color.WHITE);

        JPanel botonesControl = new JPanel(new GridLayout(1, 2, 10, 10));
        botonesControl.setBackground(fondo);

        JButton btnNueva = new JButton("NUEVA PARTIDA");
        JButton btnDificultad = new JButton("CAMBIAR DIFICULTAD");

        btnNueva.addActionListener(e -> reiniciarPartida());
        btnDificultad.addActionListener(e -> seleccionarDificultad());

        botonesControl.add(btnNueva);
        botonesControl.add(btnDificultad);

        panelControles.add(lblEstado);
        panelControles.add(botonesControl);

        inferior.add(panelControles, BorderLayout.SOUTH);

        principal.add(inferior, BorderLayout.SOUTH);

        add(principal);
    }

    public void seleccionarDificultad() {

        String[] opciones = {"Facil", "Medio", "Dificil"};

        int seleccion = JOptionPane.showOptionDialog(
                this,
                "Selecciona la dificultad",
                "Ahorcado",
                JOptionPane.DEFAULT_OPTION,
                JOptionPane.QUESTION_MESSAGE,
                null,
                opciones,
                opciones[0]
        );

        if (seleccion >= 0) {
            dificultad = seleccion + 1;
        }

        reiniciarPartida();
    }

    public void reiniciarPartida() {

        int nivel = dificultad - 1;
        int posicion = random.nextInt(palabras[nivel].length);

        palabra = palabras[nivel][posicion];
        pista = pistas[nivel][posicion];

        descubiertas = new boolean[palabra.length()];
        errores = 0;
        partidaTerminada = false;

        lblPista.setText("PISTA: " + pista);
        lblIntentos.setText("Errores: 0 / 6");
        lblEstado.setText("Selecciona una letra");
        lblEstado.setForeground(Color.WHITE);

        actualizarPalabra();

        panelTeclado.removeAll();

        for (char letra = 'A'; letra <= 'Z'; letra++) {

            final char letraActual = letra;

            JButton boton = new JButton(String.valueOf(letra));

            boton.setFont(new Font("Arial", Font.BOLD, 14));
            boton.setBackground(tarjeta);
            boton.setForeground(Color.WHITE);
            boton.setFocusPainted(false);

            boton.addActionListener(e -> {
                comprobarLetra(letraActual);
                boton.setEnabled(false);
            });

            panelTeclado.add(boton);
        }

        panelTeclado.revalidate();
        panelTeclado.repaint();

        panelDibujo.repaint();
    }

    public void actualizarPalabra() {

        StringBuilder texto = new StringBuilder();

        int descubiertasCantidad = 0;

        for (int i = 0; i < palabra.length(); i++) {

            if (descubiertas[i]) {
                texto.append(palabra.charAt(i)).append(" ");
                descubiertasCantidad++;
            } else {
                texto.append("_ ");
            }
        }

        lblPalabra.setText(texto.toString());

        int porcentaje = descubiertasCantidad * 100 / palabra.length();
        barraProgreso.setValue(porcentaje);
    }

    public void comprobarLetra(char letra) {

        if (partidaTerminada) {
            return;
        }

        boolean encontrada = false;

        for (int i = 0; i < palabra.length(); i++) {

            if (palabra.charAt(i) == letra) {
                descubiertas[i] = true;
                encontrada = true;
            }
        }

        if (encontrada) {

            lblEstado.setText("¡Letra correcta!");
            lblEstado.setForeground(verde);

        } else {

            errores++;

            lblEstado.setText("Letra incorrecta");
            lblEstado.setForeground(rojo);
        }

        lblIntentos.setText("Errores: " + errores + " / 6");

        actualizarPalabra();
        panelDibujo.repaint();

        comprobarFinal();
    }

    public void comprobarFinal() {

        boolean completa = true;

        for (boolean descubierta : descubiertas) {
            if (!descubierta) {
                completa = false;
                break;
            }
        }

        if (completa) {

            partidaTerminada = true;
            estadisticas.registrarVictoria(100 + dificultad * 100 + (6 - errores) * 25);

            lblEstado.setText("¡HAS GANADO!");
            lblEstado.setForeground(verde);

            desactivarTeclado();

            JOptionPane.showMessageDialog(
                    this,
                    "¡Felicidades! Adivinaste la palabra: " + palabra,
                    "Victoria",
                    JOptionPane.INFORMATION_MESSAGE
            );

        } else if (errores >= 6) {

            partidaTerminada = true;
            estadisticas.registrarDerrota(Math.max(0, (palabra.length() - contarDescubiertas()) * -10 + contarDescubiertas() * 10));

            lblEstado.setText("HAS PERDIDO");
            lblEstado.setForeground(rojo);

            desactivarTeclado();

            JOptionPane.showMessageDialog(
                    this,
                    "Has perdido. La palabra era: " + palabra,
                    "Derrota",
                    JOptionPane.INFORMATION_MESSAGE
            );
        }
    }

    private int contarDescubiertas() {
        int cantidad = 0;
        for (boolean descubierta : descubiertas) if (descubierta) cantidad++;
        return cantidad;
    }

    public void desactivarTeclado() {

        for (Component componente : panelTeclado.getComponents()) {
            componente.setEnabled(false);
        }
    }

    public void dibujarAhorcado(Graphics g) {

        Graphics2D g2 = (Graphics2D) g;
        g2.setStroke(new BasicStroke(5));
        g2.setColor(Color.WHITE);

        // BASE Y ESTRUCTURA
        g2.drawLine(90, 230, 250, 230);
        g2.drawLine(130, 230, 130, 35);
        g2.drawLine(130, 35, 230, 35);
        g2.drawLine(230, 35, 230, 65);

        g2.setColor(rojo);

        if (errores >= 1) {
            g2.drawOval(210, 65, 40, 40);
        }

        if (errores >= 2) {
            g2.drawLine(230, 105, 230, 160);
        }

        if (errores >= 3) {
            g2.drawLine(230, 120, 195, 145);
        }

        if (errores >= 4) {
            g2.drawLine(230, 120, 265, 145);
        }

        if (errores >= 5) {
            g2.drawLine(230, 160, 200, 200);
        }

        if (errores >= 6) {
            g2.drawLine(230, 160, 260, 200);
        }
    }
}
