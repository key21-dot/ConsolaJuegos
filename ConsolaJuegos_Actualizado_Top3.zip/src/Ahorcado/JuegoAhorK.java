package Ahorcado;

import console.DisConsola;
import Base.Juegos;
import java.util.Scanner;
import java.util.Random;


public class JuegoAhorK extends Juegos {

    private Scanner sc;
    private Random random;

    private String[][] palabras = {
            {"GATO", "PERRO", "CASA", "LUNA", "FLOR"},
            {"TECLADO", "PLANETA", "ESCUELA", "VENTANA", "COMPUTADORA"},
            {"PROGRAMACION", "INTELIGENCIA", "ARQUITECTURA",
                    "TECNOLOGIA", "UNIVERSIDAD"}
    };

    private String[][] pistas = {
            {
                    "Animal que maulla",
                    "El mejor amigo del hombre",
                    "Lugar donde vivimos",
                    "Satelite natural de la Tierra",
                    "Parte de una planta"
            },
            {
                    "Dispositivo para escribir",
                    "Gira alrededor de una estrella",
                    "Lugar donde estudiamos",
                    "Permite ver hacia el exterior",
                    "Maquina que procesa informacion"
            },
            {
                    "Creacion de programas informaticos",
                    "Capacidad de aprender y comprender",
                    "Diseno de edificios",
                    "Aplicacion practica de conocimientos",
                    "Institucion de educacion superior"
            }
    };

    public JuegoAhorK(Scanner sc) {
        super("Ahorcado");
        this.sc = sc;
        this.random = new Random();
    }

    public void mostrarDibujo(int errores) {

        System.out.println(DisConsola.AMARILLO);
        System.out.println("        +---------+");
        System.out.println("        |         |");

        System.out.println(errores >= 1
                ? "        O         |"
                : "                  |");

        if (errores == 2) {
            System.out.println("        |         |");
        } else if (errores == 3) {
            System.out.println("       /|         |");
        } else if (errores >= 4) {
            System.out.println("       /|\\        |");
        } else {
            System.out.println("                  |");
        }

        if (errores == 5) {
            System.out.println("       /          |");
        } else if (errores >= 6) {
            System.out.println("       / \\        |");
        } else {
            System.out.println("                  |");
        }

        System.out.println("                  |");
        System.out.println("      =============");
        System.out.println(DisConsola.RESET);
    }

    public void mostrarPalabra(String palabra,
                               boolean[] descubiertas) {

        System.out.print("  PALABRA: ");

        for (int i = 0; i < palabra.length(); i++) {

            if (descubiertas[i]) {
                System.out.print(DisConsola.VERDE
                        + palabra.charAt(i) + " "
                        + DisConsola.RESET);
            } else {
                System.out.print("_ ");
            }
        }

        System.out.println();
    }

    public boolean palabraCompleta(boolean[] descubiertas) {

        for (boolean descubierta : descubiertas) {
            if (!descubierta) {
                return false;
            }
        }

        return true;
    }

    @Override
    public void jugar() {

        DisConsola.titulo("AHORCADO");

        System.out.println("  [1] Facil");
        System.out.println("  [2] Medio");
        System.out.println("  [3] Dificil");
        System.out.println("  [0] Regresar");

        int nivel;

        while (true) {

            System.out.print("\n>> Dificultad: ");

            if (!sc.hasNextInt()) {
                DisConsola.error("Ingrese un numero.");
                sc.next();
                continue;
            }

            nivel = sc.nextInt();

            if (nivel == 0) {
                return;
            }

            if (nivel >= 1 && nivel <= 3) {
                break;
            }

            DisConsola.error("Opcion invalida.");
        }

        int dificultad = nivel - 1;
        int posicion = random.nextInt(palabras[dificultad].length);

        String palabra = palabras[dificultad][posicion];
        String pista = pistas[dificultad][posicion];

        boolean[] descubiertas = new boolean[palabra.length()];

        String letrasUsadas = "";
        int errores = 0;

        while (errores < 6) {

            DisConsola.titulo("PARTIDA DE AHORCADO");

            System.out.println("  PISTA: " + pista);
            System.out.println("  ERRORES: " + errores + "/6");

            DisConsola.mostrarIntentos(errores, 6);

            mostrarDibujo(errores);
            mostrarPalabra(palabra, descubiertas);

            int letrasDescubiertas = 0;

            for (boolean descubierta : descubiertas) {
                if (descubierta) {
                    letrasDescubiertas++;
                }
            }

            System.out.println();
            System.out.println("  PROGRESO DE LA PALABRA:");
            DisConsola.barraProgreso(
                    letrasDescubiertas, palabra.length());

            DisConsola.separador();

            System.out.println("  LETRAS USADAS: "
                    + (letrasUsadas.isEmpty() ? "Ninguna" : letrasUsadas));

            System.out.println("  [0] Abandonar partida");
            System.out.print("\n>> Ingrese una letra: ");

            String entrada = sc.next().toUpperCase();

            if (entrada.equals("0")) {
                DisConsola.mensaje("Regresando al menu...");
                return;
            }

            if (entrada.length() != 1 ||
                    !Character.isLetter(entrada.charAt(0))) {

                DisConsola.error("Ingrese solamente una letra.");
                continue;
            }

            char letra = entrada.charAt(0);

            if (letrasUsadas.indexOf(letra) != -1) {
                DisConsola.error("Ya utilizaste esa letra.");
                continue;
            }

            letrasUsadas += letra + " ";

            boolean encontrada = false;

            for (int i = 0; i < palabra.length(); i++) {

                if (palabra.charAt(i) == letra) {
                    descubiertas[i] = true;
                    encontrada = true;
                }
            }

            if (encontrada) {
                DisConsola.exito("Letra correcta!");
            } else {
                errores++;
                DisConsola.error("Letra incorrecta!");
            }

            if (palabraCompleta(descubiertas)) {

                mostrarPalabra(palabra, descubiertas);

                System.out.println();
                DisConsola.barraProgreso(
                        palabra.length(), palabra.length());

                DisConsola.victoria();

                getEstadistica().registrarVictoria(100 + nivel * 100 + (6 - errores) * 25);
                return;
            }
        }

        mostrarDibujo(errores);
        DisConsola.mostrarIntentos(errores, 6);
        DisConsola.derrota();

        System.out.println("  La palabra era: " + palabra);

        getEstadistica().registrarDerrota(0);
    }
}
