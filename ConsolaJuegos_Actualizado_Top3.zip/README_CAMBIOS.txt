GAME CONSOLE - VERSION ACTUALIZADA

EJECUCION EN INTELLIJ
1. Abrir la carpeta como proyecto Java y configurar el JDK.
2. Ejecutar gameconsole.Main para la interfaz grafica.
3. Opcional: ejecutar gameconsole.MainConsola para la consola de texto.
4. Introducir el nombre del jugador y jugar una partida completa.
5. Abrir ESTADISTICAS para ver victorias, derrotas, empates y Top 3 por juego.

CAMBIOS
- Puntuacion implementa Comparable<Puntuacion> y compareTo ordena descendente.
- Estadisticas registra resultados y puntos, calcula porcentajes y Top 3.
- RegistroEstadisticas comparte las estadisticas entre las ventanas y la consola.
- Tres registros iniciales de demostracion por juego, marcados [EJEMPLO].
- Los resultados reales se agregan automaticamente al finalizar cada partida.
- Los juegos mantienen sus paquetes y el metodo star() original de Jugable.
- Se agrego MainConsola para probar la version de texto.

PUNTUACION
Ahorcado: 100 + dificultad*100 + intentos restantes*25 al ganar.
Tres en raya: 200 + dificultad*100 al ganar, 100 al empatar.
PPT: 100 por ronda ganada y 10 por ronda empatada al ganar;
     50 por ronda ganada y 10 por ronda empatada al perder.
Las partidas perdidas de Ahorcado y Tres en raya reciben 0 puntos.

NOTA: el ranking y las estadisticas se conservan durante la ejecucion,
pero no se guardan entre reinicios del programa. Los ejemplos son ficticios.
